from django.shortcuts import render
from django.http import HttpResponse
from django.core.files.storage import FileSystemStorage
from pprint import pprint
import pathlib

# Create your views here.
def fileUpload(request):

    try:
        if request.method == 'POST' and len(request.FILES) > 0:
            for key, fn in request.FILES.items():
                fs = FileSystemStorage()

                # check if file already exists
                if fs.exists(fn.name):
                    fs.delete(fn.name)

                _ = fs.save(fn.name, fn)
        elif request.method != 'POST':
            print("[ERROR] File uploads require a Post-Request.")
            print(f"-------> Request type was {request.method}.")
        elif len(request.FILES) == 0:
            print("[ERROR] No files found in request.")
            print("------> Original Request:")

            data = request.__dict__.copy()
            data.pop('META', None)
            data.pop('environ', None)

            pprint(data)
    except Exception as e:
        print(f'[ERROR] Excetpion occured during file upload: {e}')
        print("------> Original Request:")

        data = request.__dict__.copy()
        data.pop('META', None)
        data.pop('environ', None)

        pprint(data)

    return HttpResponse()
