from django.urls import path
from devicesbackend import views


urlpatterns = [
    path('upload/', views.fileUpload),
]
