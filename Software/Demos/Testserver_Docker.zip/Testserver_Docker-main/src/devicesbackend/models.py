from django.db import models

# Create your models here.
class AudioFile(models.Model):
    title = models.CharField(max_length=255, blank=True)
    file = models.FileField(upload_to='memos/')
    timestamp = models.DateTimeField(auto_now_add=True)