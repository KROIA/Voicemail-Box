from django.apps import AppConfig


class WebinterfaceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'webinterface'
