from django.urls import path
from webinterface import views


urlpatterns = [
    path('', views.webHome, name="Voicemail Home"),
    path('home/', views.webHome, name="Voicemail Home"),
    # path('device/')
]