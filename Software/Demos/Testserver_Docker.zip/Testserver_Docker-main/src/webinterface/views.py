from django.shortcuts import render, redirect
from django.http import HttpResponse, Http404
from django.conf import settings
from django.core.files.storage import FileSystemStorage
import os
from pprint import pprint


# Create your views here.
def webHome(request):

    fs = FileSystemStorage()
    dirs, files = fs.listdir(fs.base_location)

    file_list = []
    for f in files:
        name = fs.get_valid_name(f)
        file_list.append({ 'filename': name,
                            'size': fs.size(os.path.join(fs.base_location, name)),
                            'timestamp': fs.get_created_time(os.path.join(fs.base_location, name)),
                            'url': fs.url(f)})    

    return render(request, 'home.html', {"dataset": file_list})