import pathlib
import sys

rel_target_path = ['..', 'src', 'Voicemail_SA_Server', 'settings.py']


if __name__ == '__main__':
    file_dir = pathlib.Path(__file__).parent.resolve()
    file_dir = file_dir.joinpath(*rel_target_path)

    still_in_develop = True

    with open(file_dir, 'r') as f:
        for line in f.readlines():
            token = line.replace(' ', '')
            if 'DEBUG=True' in token:
                still_in_develop = True
                break
            elif 'DEBUG=False' in token:
                still_in_develop = False
                break

    if still_in_develop:
        print("Django server is set up for development. Please make sure DEBUG = False in settings.py")
        sys.exit(1)

    sys.exit(0)
