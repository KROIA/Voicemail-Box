cd ..

python3 -m venv venv

./venv/bin/pip3 install -r ./setup/requirements.txt
./venv/bin/python3 ./src/manage.py makemigrations
./venv/bin/python3 ./src/manage.py migrate
./venv/bin/python3 ./src/manage.py check