# Testserver_Docker

This is the Testserver for the Voicemail Box SA in the spring semester 2025.

## Setup

Run the setup script to configure a virtual environment for the project.
On Windows, this is done by running ```setup\setup.bat```. For Linux, run ```setup/setup.sh```.

## Running the Server

Start the server by running ```run.bat``` on Windows or ```run.sh``` on Linux.

*Note:* The server automatically updates any changed files during runtime and does not need to be restarted unless an exception occurs.

## Usage

**IMPORTANT** Virtually all security features are disabled. This server is **not** ready for production.

### View Server Files

The server will listen on the port ```8000```. You can access the webinterface by visiting ```http://127.0.0.1:8000/webinterface/```. It will show you all files currently on the server and allows you to download them.

*Note:* There should already be a default file called test.txt.

### Uploading a file

1) On the sender PC, open the terminal and type the following command:
2) `curl -F 'test=@test.txt' serverip:8000/devicesbackend/upload/`
   > `serverip` is the IP address of the server machine.
  
   > Execute the command in a directory where the file `test.txt` is avilable or enter the full file path there.

---
### Downloading a file
1) On the sender PC, open the terminal and type the following command:
2) `curl -O serverip:8000/media/test.txt`
   > `serverip` is the IP address of the server machine.

   > `media/` is the servers download path.

   > `test.txt` is the target file to download, it will be downloaded to the location the command was executed from.
